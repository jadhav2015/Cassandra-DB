package com.cassandra.util;

public class OperationsUtils
{

    public static String createKeyspaceQuery(String keyspace)
    {
        //create keyspace
        String createKeySpaceQuery = "CREATE KEYSPACE "+keyspace+ " WITH replication "
                + "= {'class':'SimpleStrategy', 'replication_factor':1};";
        return createKeySpaceQuery;
    }

    public static String dropKeyspaceQuery(String keyspace)
    {
        //drop key space
        String dropKeyspaceQuery = "DROP KEYSPACE "+keyspace;
        return dropKeyspaceQuery;
    }

    public static String createTableQuery(String tableName)
    {
        //create table
        String createTableQuery ="CREATE TABLE "+tableName+"(emp_id int PRIMARY KEY, "
                + "emp_name text, "
                + "emp_city text, "
                + "emp_sal varint, "
                + "emp_phone varint );";
        return createTableQuery;
    }

    public static String insertData(String tableName)
    {
        //insert data
        String insertData = "INSERT INTO empTable (emp_id, emp_name, emp_city,"
            +"emp_phone, emp_sal) VALUES(2,'Ravi kumar', 'Kabul', 9848022378, 10000); ";
        return insertData;
    }

    public static String updateData(String tableName)
    {
        //update data
        String updateData= "UPDATE empTable SET emp_city='Delhi',emp_sal=50000  WHERE emp_id = 2 ";

        return updateData;
    }
    public static String deleteData(String tableName)
    {
        //delete data
        String deleteData = "DELETE FROM empTable WHERE emp_id=2;";
        return deleteData;
    }
    public static String  getData(String tableName)
    {
        // get data
        String empDetails="select * from empTable";
        return empDetails;
    }

}
