package com.cassandra.util;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Session;

public class CassConnection
{

     public static Cluster cluster;
     public static Session session;

     // creating cluster
    public static Cluster createCluster()
    {
        if (cluster==null)
        {
            cluster= Cluster.builder().addContactPoint("127.0.0.1").build();
        }
        return cluster;
    }

    public static Session createSession()
    {
        if(session==null)
        {
         session=CassConnection.createCluster().connect();
        }
        return session;
    }

}
