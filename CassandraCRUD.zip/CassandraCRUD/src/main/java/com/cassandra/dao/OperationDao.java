package com.cassandra.dao;

import com.cassandra.util.CassConnection;
import com.cassandra.util.OperationsUtils;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;

public class OperationDao
{
    public boolean performOperation(String  operation,String keyspace,String tableName) {

        Session session= CassConnection.createSession();

        switch (operation) {

            case "createKeySpace":
                String createKeyspaceQuery=OperationsUtils.createKeyspaceQuery(keyspace);
                session.execute(createKeyspaceQuery);
                System.out.println("key space created successfully");
                break;
            case "dropKeySpace":
                String dropKeySpaceQuery=OperationsUtils.dropKeyspaceQuery(keyspace);
                session.execute(dropKeySpaceQuery);
                System.out.println("key space dropped successfully");
                break;
            case "createTable":
                String createTable=OperationsUtils.createTableQuery(tableName);
                System.out.println(createTable);
                session=CassConnection.createCluster().connect(keyspace);
                session.execute(createTable);
                System.out.println("table created successfully ");
                break;
            case "insertData":
                String insertData=OperationsUtils.insertData(tableName);
                System.out.println(insertData);
                session=CassConnection.createCluster().connect(keyspace);
                session.execute(insertData);
                System.out.println("data inserted successfully ");
                break;

            case "updateData":
                String updateData=OperationsUtils.updateData(tableName);
                System.out.println(updateData);
                session=CassConnection.createCluster().connect(keyspace);
                session.execute(updateData);
                System.out.println("table created successfully ");
                break;

            case "deleteData":
                String deleteData=OperationsUtils.deleteData(tableName);
                System.out.println(deleteData);

                session=CassConnection.createCluster().connect(keyspace);
                session.execute(deleteData);
                System.out.println("table created successfully ");
                break;

            case "getData":

                String getData=OperationsUtils.getData(tableName);
                System.out.println(getData);

                session=CassConnection.createCluster().connect(keyspace);
                ResultSet result = session.execute(getData);
                System.out.println("table date  "+result.all());
                break;

             default:
                System.out.println("please provide valid input");
        }

      return true;
    }
}
