package com.cassandra;

import com.cassandra.dao.OperationDao;

import java.util.Scanner;

public class CassandraDemo
{
    public static void main(String args[])
    {

        OperationDao operationDao=new OperationDao();
        //please enter the operation want to perform
        Scanner scan=new Scanner(System.in);
        System.out.println("please enter operation name");
        String operation=scan.next().trim();

         System.out.println("enter key space");
         String keyspaceName=scan.next().trim();

         System.out.println("enter  table  name");
         String tableName=scan.next().trim();

        operationDao.performOperation(operation,keyspaceName,tableName);
        System.out.println(operation+" executed successfully");
    }
}
